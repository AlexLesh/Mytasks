import java.util.Random;

public class Main {

public static void main(String[] args) {
Random random = new Random();
Animal[] animals = new Animal[10]; 


for (int i = 0; i < animals.length; i++) {
int randomAnimal = random.nextInt(4); 
switch (randomAnimal) {
case 0:
animals[i] = new Dog("Собака" + i);
break;
case 1:
animals[i] = new Domesticcat("Кот" + i);
break;
case 2:
animals[i] = new Tiger("Тигр" + i);
break;
case 3:
animals[i] = new Wolf("Волк" + i);
}
}


for (Animal animal : animals) {
int runDistance = random.nextInt(1000) + 1; 
int swimDistance = random.nextInt(1000) + 1; 

animal.run(runDistance);
animal.swim(swimDistance);
}
}
}