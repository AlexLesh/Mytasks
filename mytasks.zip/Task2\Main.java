public class Main {
public static void main(String[] args) {
Author author = new Author("Ivan Ivanov", "i.ivanov@somewhere.com", 'm');
Book book = new Book("My Book", author, 19.99, 100);

System.out.println("Author: " + author);
System.out.println("Book: " + book);
}
}