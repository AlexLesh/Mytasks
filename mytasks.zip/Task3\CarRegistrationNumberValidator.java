import java.util.*;

public class CarRegistrationNumberValidator {
    private static final Map<Integer, String> regionMap = new HashMap<>();

    static {
        regionMap.put(77, "Москва");
        regionMap.put(97, "Москва");
        regionMap.put(777, "Москва");
        regionMap.put(50, "Московская область");
        regionMap.put(18, "Удмуртская республика");
        // Можно добавить другие регионы и номера сюда
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Введите часть номера автомобиля без региона (например, 'A111AA'): ");
            String lettersPart = scanner.nextLine().toUpperCase();

            if (lettersPart.equals("EXIT")) {
                System.out.println("Программа завершена.");
                break;
            }

            System.out.println("Введите код региона (например, '77'): ");
            int regionCode = scanner.nextInt();
            scanner.nextLine(); // Очистка буфера после ввода числа

            String carNumber = lettersPart + regionCode;

            String validationResult = validateCarNumber(carNumber);

            if (validationResult.equals("VALID")) {
                String region = getRegionFromCarNumber(regionCode);
                if (region != null) {
                    System.out.println("Номер корректен. Регион: " + region);
                } else {
                    System.out.println("Регион не найден. Код региона: " + regionCode);
                }
            } else {
                System.out.println("Номер некорректен. Причина: " + validationResult);
            }
        }

        scanner.close();
    }

    private static String validateCarNumber(String carNumber) {
        String regex = "^[ABEKMHOPCTYX]{1}\\d{3}[ABEKMHOPCTYX]{2}\\d{2,3}$";
        if (carNumber.matches(regex)) {
            return "VALID";
        } else {
            return "Некорректный формат номера.";
        }
    }

    private static String getRegionFromCarNumber(int regionCode) {
        String region = regionMap.get(regionCode);
        return region;
    }
}