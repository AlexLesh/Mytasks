public class Tiger extends Animal {

    public Tiger(String name) {
        super(name, 1000, 0);
        }
    
}
