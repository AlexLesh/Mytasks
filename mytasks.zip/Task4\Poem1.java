import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Poem1 {
public static void main(String[] args) {
try (BufferedReader reader = new BufferedReader(new FileReader("poem.txt"))) {
String line;
int paragraphNumber = 1;
StringBuilder paragraph = new StringBuilder();

while ((line = reader.readLine()) != null) {
// Пустая строка означает конец абзаца
if (line.isEmpty()) {
// Записываем абзац в новый файл
try (BufferedWriter writer = new BufferedWriter(new FileWriter("part" + paragraphNumber + ".txt"))) {
writer.write(paragraph.toString());
}
paragraphNumber++;
paragraph.setLength(0); // Очищаем буфер для следующего абзаца
} else {
// Добавляем строку к текущему абзацу
paragraph.append(line).append("\n");
}
}

// Завершаем запись последнего абзаца
if (paragraph.length() > 0) {
try (BufferedWriter writer = new BufferedWriter(new FileWriter("part" + paragraphNumber + ".txt"))) {
writer.write(paragraph.toString());
}
}

System.out.println("Файлы созданы успешно.");
} catch (IOException e) {
e.printStackTrace();
}
}
}