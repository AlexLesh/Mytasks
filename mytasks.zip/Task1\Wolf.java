public class Wolf extends Animal {
    public Wolf(String name) {
        super(name, 800, 50);
        }
}
