public abstract class Animal {
    private String name;
    private int maxRunDistance;
    private int maxSwimDistance;
    
    public Animal(String name, int maxRunDistance, int maxSwimDistance) {
    this.name = name;
    this.maxRunDistance = maxRunDistance;
    this.maxSwimDistance = maxSwimDistance;
    }
    
    public void run(int distance) {
    if (distance <= maxRunDistance) {
    System.out.println(name + " пробежал " + distance + " м.");
    } else {
    System.out.println(name + " не может пробежать " + distance + " м.");
    }
    }
    
    public void swim(int distance) {
    if (distance <= maxSwimDistance) {
    System.out.println(name + " проплыл " + distance + " м.");
    } else {
    System.out.println(name + " не может проплыть " + distance + " м.");
    }
    }
    }