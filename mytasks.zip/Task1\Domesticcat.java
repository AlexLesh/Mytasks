public class Domesticcat extends Animal {
    
    public Domesticcat(String name) {
        super(name, 200, 0);
        }
}
