import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

public class Poem2 {
public static void main(String[] args) {
Queue<String> queue = new LinkedList<>();

try (BufferedReader reader = new BufferedReader(new FileReader("poem.txt"))) {
String line;

while ((line = reader.readLine()) != null) {
// Добавляем каждую строку в очередь
queue.add(line);
}
} catch (IOException e) {
e.printStackTrace();
}

// Вызываем метод для вывода строк из очереди с задержкой
printQueueWithRandomDelay(queue);
}

public static void printQueueWithRandomDelay(Queue<String> queue) {
Random random = new Random();

while (!queue.isEmpty()) {
String line = queue.poll();
System.out.println("Считано: " + line);

// Генерируем случайную задержку от 1 до 3 секунд
int delay = random.nextInt(3) + 1;
try {
Thread.sleep(delay * 1000); // Переводим секунды в миллисекунды
} catch (InterruptedException e) {
e.printStackTrace();
}
}
}
}